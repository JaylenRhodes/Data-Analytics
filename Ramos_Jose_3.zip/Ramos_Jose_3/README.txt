Part 1:
	I selected 3 distinct literature pieces for this assignment, a poem, a speech and a short story.
	They are each briefly described within the Jupyter file
	
Part 2:
	Word count computation was done exactly the same way that was demonstrated in the lecture videos.
	Once the data was gathered in a data-frame, I then converted to a bar graph with matplot ax functionality.
	Word clouds were a bit difficult only because the saved variable is a list and not a string like it wants.
	Initially I tried converting from list to string but that didn't work for some reason.
	I decided that manually creating the results into a string text file using a character repetition generator would be my best 		action.
	That's what I ended up doing and it worked well.
	The wordclouds are plotted within the Jupyter file, didn't want to export to png files
	
Part 3:
	This part was simple, just set a path to the files using the textastic library to find the results and store to a dictionary.
	From there I went through, selected the components I needed from the dictionaries and added them together, then divided by 4 		to get the average.
	
Part 4:
	Similar to part 3, this was just creating variables, then using the proper library to compare the different text files.
	I went ahead and made it the same way almost as the lecture video.
	
Part 5:
	This part depended a bit on the previous, went ahead and created different variables just to play it safe and also to 		distinguish. 
	Took almost everything from part 1 and modified it a bit, except this time instead of repeating code, I just made functions 
	to handle with them.
	
More details are found in the comments of the Jupyter file.
